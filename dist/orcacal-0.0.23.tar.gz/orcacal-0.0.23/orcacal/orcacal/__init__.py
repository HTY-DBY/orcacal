from orcacal.orcacal.orcacal import run, set_calfun, set_nprocs, set_maxcore, set_location, make_molden, generate_xyz
