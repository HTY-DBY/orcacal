# from .orcacal import set_calfun, set_nprocs, set_maxcore, run, make_molden, set_location
from .get import get as _get
from .orcacal import *
