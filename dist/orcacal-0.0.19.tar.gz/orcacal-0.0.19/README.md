<h1 align="center">
<img src="https://i.postimg.cc/wjY6JGFL/image.png" width="100">
</h1>

# 1. 说明

更新中 使用 python 调用 ORCA 进行计算，并封装了常用计算方法，

# 2. Star History

[![Star History Chart](https://api.star-history.com/svg?repos=HTY-DBY/orcacal&type=Date)](https://star-history.com/#HTY-DBY/orcacal&Date)
